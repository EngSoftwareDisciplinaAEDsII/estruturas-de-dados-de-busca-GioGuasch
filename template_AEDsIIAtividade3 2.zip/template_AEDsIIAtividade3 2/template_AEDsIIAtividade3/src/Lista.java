public class Lista<E> {

    private static class Node<E> {
        E item;
        Node<E> next;

        Node(E item) {
            this.item = item;
        }
    }

    private Node<E> head;
    private Node<E> tail;
    private int tamanho;

    public Lista() {
        head = tail = null;
        tamanho = 0;
    }

    public void adicionar(E item) {
        Node<E> n = new Node<>(item);
        if (head == null) {
            head = tail = n;
        } else {
            tail.next = n;
            tail = n;
        }
        tamanho++;
    }

    public void adicionarTodos(Lista<E> outra) {
        if (outra == null || outra.isVazia()) return;
        for (Node<E> cur = outra.head; cur != null; cur = cur.next) {
            this.adicionar(cur.item);
        }
    }

    public boolean isVazia() {
        return tamanho == 0;
    }

    public int tamanho() {
        return tamanho;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        Node<E> cur = head;
        while (cur != null) {
            if (sb.length() > 0) sb.append(",");
            sb.append(cur.item);
            cur = cur.next;
        }
        return sb.toString();
    }
}
