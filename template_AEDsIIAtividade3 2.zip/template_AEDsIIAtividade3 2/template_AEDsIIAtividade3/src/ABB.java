import java.util.Comparator;
import java.util.NoSuchElementException;
import java.util.function.Function;

public class ABB<K, V> implements IMapeamento<K, V>{

	private No<K, V> raiz; // referência à raiz da árvore.
	private Comparator<K> comparador; //comparador empregado para definir "menores" e "maiores".
	private int tamanho;
	
	/**
	 * Método auxiliar para inicialização da árvore binária de busca.
	 * 
	 * Este método define a raiz da árvore como {@code null} e seu tamanho como 0.
	 * Se o comparador fornecido for {@code null}, o comparador padrão de ordem natural
	 * será utilizado.
	 * 
	 * @param comparador o comparador para organizar os elementos da árvore.
	 */
	@SuppressWarnings("unchecked")
	private void init(Comparator<K> comparador) {
		raiz = null;
		tamanho = 0;
		if (comparador == null) {
			comparador = (Comparator<K>) Comparator.naturalOrder();
		}
		this.comparador = comparador;
	}
	
	/**
     * Construtor da classe.
     * Esse construtor cria uma nova árvore binária de busca vazia. Para isso, esse método atribui null à raiz da árvore.
     */
    public ABB() {
        init(null);
    }

    /**
     * Construtor da classe.
     * Esse construtor cria uma nova árvore binária de busca vazia utilizando o
     * comparador fornecido para definir a organização dos elementos na árvore.
     * Para isso, esse método atribui null à raiz da árvore.
     *  
     * @param comparador o comparador a ser utilizado para organizar os elementos da árvore.  
     */
    public ABB(Comparator<K> comparador) {
        init(comparador);
    }
    
    /**
     * Construtor da classe.
     * Esse construtor cria uma nova árvore binária a partir de uma outra árvore binária de busca,
     * com os mesmos itens, mas usando uma nova chave.
     * @param original a árvore binária de busca original.
     * @param funcaoChave a função que irá extrair a nova chave de cada item para a nova árvore.
     */
    public ABB(ABB<?,V> original, Function<V,K> funcaoChave) {
        ABB<K,V> nova = new ABB<>();
        nova = copiarArvore(original.raiz, funcaoChave, nova);
        this.raiz = nova.raiz;
    }
    
    /**
     * Recursivamente, copia os elementos da árvore original para esta, num processo análogo ao caminhamento em ordem.
     * @param <T> Tipo da nova chave.
     * @param raizArvore raiz da árvore original que será copiada.
     * @param funcaoChave função extratora da nova chave para cada item da árvore.
     * @param novaArvore Nova árvore. Parâmetro usado para permitir o retorno da recursividade.
     * @return A nova árvore com os itens copiados e usando a chave indicada pela função extratora.
     */
    private <T> ABB<T,V> copiarArvore(No<?,V> raizArvore, Function<V,T> funcaoChave, ABB<T,V> novaArvore) {
    	
        if (raizArvore != null) {
    		novaArvore = copiarArvore(raizArvore.getEsquerda(), funcaoChave, novaArvore);
            V item = raizArvore.getItem();
            T chave = funcaoChave.apply(item);
    		novaArvore.inserir(chave, item);
    		novaArvore = copiarArvore(raizArvore.getDireita(), funcaoChave, novaArvore);
    	}
        return novaArvore;
    }

    /**
     * Método booleano que indica se a árvore está vazia ou não.
     * @return
     * verdadeiro: se a raiz da árvore for null, o que significa que a árvore está vazia.
     * falso: se a raiz da árvore não for null, o que significa que a árvore não está vazia.
     */
    public Boolean vazia() {
        return (this.raiz == null);
    }
    
    @Override
    /**
     * Método que encapsula a pesquisa recursiva de itens na árvore.
     * @param chave a chave do item que será pesquisado na árvore.
     * @return o valor associado à chave.
     */
	public V pesquisar(K chave) {	
    	return pesquisar(raiz, chave);
    }
    
    private V pesquisar(No<K, V> raizArvore, K procurado) {
    	
    	int comparacao;
    	
    	if (raizArvore == null)
    		/// Se a raiz da árvore ou sub-árvore for null, a árvore/sub-árvore está vazia e então o item não foi encontrado.
    		throw new NoSuchElementException("O item não foi localizado na árvore!");
    	
    	comparacao = comparador.compare(procurado, raizArvore.getChave());
    	
    	if (comparacao == 0)
    		/// O item procurado foi encontrado.
    		return raizArvore.getItem();
    	else if (comparacao < 0)
    		/// Se o item procurado for menor do que o item armazenado na raiz da árvore:
            /// pesquise esse item na sub-árvore esquerda.    
    		return pesquisar(raizArvore.getEsquerda(), procurado);
    	else
    		/// Se o item procurado for maior do que o item armazenado na raiz da árvore:
            /// pesquise esse item na sub-árvore direita.
    		return pesquisar(raizArvore.getDireita(), procurado);
    }
    
    @Override
    /**
     * Método que encapsula a adição recursiva de itens à árvore, associando-o à chave fornecida.
     * @param chave a chave associada ao item que será inserido na árvore.
     * @param item o item que será inserido na árvore.
     * 
     * @return o tamanho atualizado da árvore após a execução da operação de inserção.
     */
	public int inserir(K chave, V item) {
		this.raiz = inserir(this.raiz, chave, item);
		return this.tamanho;
	}
    
    /**
     * Método recursivo responsável por adicionar um item à árvore.
     * @param raizArvore a raiz da árvore ou sub-árvore em que o item será adicionado.
     * @param chave a chave associada ao item que deverá ser inserido.
     * @param item o item que deverá ser adicionado à árvore.
     * @return a raiz atualizada da árvore ou sub-árvore em que o item foi adicionado.
     * @throws RuntimeException se um item com a mesma chave já estiver presente na árvore.
     */
    protected No<K, V> inserir(No<K, V> raizArvore, K chave, V item) {
        if (raizArvore == null) {
            this.tamanho++;
            return new No<>(chave, item);
        }

        int cmp = comparador.compare(chave, raizArvore.getChave());
        if (cmp == 0) {
            throw new RuntimeException("Chave já presente na árvore");
        } else if (cmp < 0) {
            raizArvore.setEsquerda(inserir(raizArvore.getEsquerda(), chave, item));
        } else {
            raizArvore.setDireita(inserir(raizArvore.getDireita(), chave, item));
        }
        return raizArvore;
    }

    @Override 
    public String toString(){
        StringBuilder sb = new StringBuilder();
        try {
            percorrer();
        } catch (Exception e) {
            // fallback
        }
        return sb.toString();
    }

    @Override
	public String percorrer() {
        StringBuilder sb = new StringBuilder();
        percorrerEmOrdem(this.raiz, sb);
        return sb.toString();
	}

    private void percorrerEmOrdem(No<K, V> no, StringBuilder sb) {
        if (no == null) return;
        percorrerEmOrdem(no.getEsquerda(), sb);
        if (sb.length() > 0) sb.append(",");
        sb.append(no.getChave());
        percorrerEmOrdem(no.getDireita(), sb);
    }
    
	@Override
	/**
     * Método que encapsula a remoção recursiva de um item da árvore.
     * @param chave a chave do item que deverá ser localizado e removido da árvore.
     * @return o valor associado ao item removido.
	 */
	public V remover(K chave) {
        throw new UnsupportedOperationException("Remover não implementado");
	}

	@Override
	public int tamanho() {
		return tamanho;
	}
	
	@Override
	public long getComparacoes() {
        throw new UnsupportedOperationException("getComparacoes não implementado");
	}

	@Override
	public double getTempo() {
        throw new UnsupportedOperationException("getTempo não implementado");
	}

    /**
     * Retorna uma nova ABB contendo apenas as entradas cuja chave está no intervalo [Kmin, Kmax] (inclusivo).
     *
     * @param Kmin limite inferior (inclusivo)
     * @param Kmax limite superior (inclusivo)
     * @return nova ABB com as chaves no intervalo
     */
    public ABB<K, V> recorte(K Kmin, K Kmax) {
        if (Kmin == null || Kmax == null) {
            throw new IllegalArgumentException("Kmin e Kmax não podem ser null");
        }
        if (comparador.compare(Kmin, Kmax) > 0) {
            throw new IllegalArgumentException("Kmin não pode ser maior que Kmax");
        }
        return recorte(this.raiz, Kmin, Kmax);
    }

    private ABB<K,V> recorte(No<K,V> no, K Kmin, K Kmax) {
        ABB<K,V> resultado = new ABB<>(this.comparador);
        if (no == null) return resultado;
        // recorta subárvores esquerda e direita
        ABB<K,V> esquerdaRecortada = recorte(no.getEsquerda(), Kmin, Kmax);
        ABB<K,V> direitaRecortada = recorte(no.getDireita(), Kmin, Kmax);
        // se o nó atual estiver no intervalo, adiciona-o à árvore esquerdaRecortada
        if (comparador.compare(no.getChave(), Kmin) >= 0 && comparador.compare(no.getChave(), Kmax) <= 0) {
            esquerdaRecortada.inserir(no.getChave(), no.getItem());
        }
        // insere todos os elementos da direitaRecortada em esquerdaRecortada
        inserirTodos(esquerdaRecortada, direitaRecortada.raiz);
        return esquerdaRecortada;
    }

    /**
     * Insere recursivamente todos os nós da subárvore `no` na árvore `destino`.
     */
    private void inserirTodos(ABB<K,V> destino, No<K,V> no) {
        if (no == null) return;
        inserirTodos(destino, no.getEsquerda());
        destino.inserir(no.getChave(), no.getItem());
        inserirTodos(destino, no.getDireita());
    }

    /**
     * Retorna uma lista contendo todas as chaves maiores que a chave informada.
     */
    public Lista<K> chavesMaiores(K chave) {
        if (chave == null) throw new IllegalArgumentException("chave não pode ser null");
        return chavesMaiores(this.raiz, chave);
    }

    /**
     * Método recursivo que retorna uma lista com todas as chaves maiores que `chave`.
     * Assinatura exigida: private Lista<K> chavesMaiores(No<K, V> no, K chave)
     */
    private Lista<K> chavesMaiores(No<K, V> no, K chave) {
        Lista<K> resultado = new Lista<>();
        if (no == null) return resultado;

        int cmp = comparador.compare(no.getChave(), chave);
        if (cmp <= 0) {
            // nó e toda subárvore esquerda são <= chave — procurar apenas à direita
            return chavesMaiores(no.getDireita(), chave);
        } else {
            // nó.getChave() > chave: coletar da esquerda as maiores que chave
            Lista<K> esquerda = chavesMaiores(no.getEsquerda(), chave);
            // adicionar chave do nó atual
            esquerda.adicionar(no.getChave());
            // adicionar todas as chaves da subárvore direita (são todas > nó.chave > chave)
            Lista<K> todasDireita = todasChaves(no.getDireita());
            esquerda.adicionarTodos(todasDireita);
            return esquerda;
        }
    }

    /**
     * Retorna uma lista com todas as chaves da subárvore (in-order).
     */
    private Lista<K> todasChaves(No<K, V> no) {
        Lista<K> res = new Lista<>();
        if (no == null) return res;
        Lista<K> left = todasChaves(no.getEsquerda());
        res.adicionarTodos(left);
        res.adicionar(no.getChave());
        Lista<K> right = todasChaves(no.getDireita());
        res.adicionarTodos(right);
        return res;
    }
}